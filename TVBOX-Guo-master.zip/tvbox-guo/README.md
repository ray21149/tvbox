tvbox配置文件。所有资源均来自于各路大神无私分享，如有侵权，请联系删除。
1. tvbox配置：

（1）0820.json  较全面的源，jar的来源于WEWA（饭太硬）的jar包；

（2）0820.txt  精简的源，jar的来源唐三的jar包；

（3）0826.json  完全来源于WEWA（饭太硬）的jar包和配置；

（4）0827.json  jar包和配置来源于fongmi；

（5）0828.json  完全来源于唐三的jar包和配置；

（7）js.json  资源来源于猫爪收集整理的道长drpy(js)资源；

（8）xBPQ.json  纯xBPQ源，jar包和配置来源于菜妮丝。

APP推荐使用FongMi版本（项目地址：https://github.com/FongMi/TV ）和q215613905版本（项目地址：https://github.com/q215613905/TVBoxOS ），FongMi版支持直播多线路，q215613905版支持直播回放。

2. TVBox各路大佬配置（排名不分先后）：

（1）唐三：https://hutool.ml/tang

（2）Fongmi：https://raw.fastgit.org/FongMi/CatVodSpider/main/json/config.json

（3）俊于：http://home.jundie.top:81/top98.json

（4）饭太硬：http://饭太硬.ga/x/o.json

（5）肥猫：http://我不是.肥猫.love:63/接口禁止贩卖

（6）霜辉月明py：https://ghproxy.com/raw.githubusercontent.com/lm317379829/PyramidStore/pyramid/py.json

（7）小雅dr：http://drpy.site/js1

（8）菜妮丝：https://tvbox.cainisi.cf

（9）神器：https://神器每日推送.tk/pz.json

（10）巧技：http://pandown.pro/tvbox/tvbox.json

（11）刚刚：http://刚刚.live/猫

（12）吾爱有三：http://52bsj.vip:98/0805

（13）潇洒：https://download.kstore.space/download/2863/01.txt

（14）佰欣园：https://ghproxy.com/https://raw.githubusercontent.com/chengxueli818913/maoTV/main/44.txt

（15）胖虎：https://notabug.org/imbig66/tv-spider-man/raw/master/配置/0801.json

（16）云星日记：https://maoyingshi.cc/tvbox/云星日记/1.m3u8

（17）Yoursmile7：https://agit.ai/Yoursmile7/TVBox/raw/branch/master/XC.json

（18）BOX：http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0

（19）哔哩学习：http://52bsj.vip:81/api/v3/file/get/41063/bili.json?sign=TxuApYZt6bNl9TzI7vObItW34UnATQ4RQxABAEwHst4%3D%3A0

（20）UndCover：https://raw.githubusercontent.com/UndCover/PyramidStore/main/py.json

（21）木极：https://pan.tenire.com/down.php/2664dabf44e1b55919f481903a178cba.txt  

（22）Ray：https://dxawi.github.io/0/0.json

（23）甜蜜：https://kebedd69.github.io/TVbox-interface/py甜蜜.json

（24）52bsj：http://52bsj.vip:81/api/v3/file/get/29899/box2.json?sign=3cVyKZQr3lFAwdB3HK-A7h33e0MnmG6lLB9oWlvSNnM%3D%3A0

（25）免费解析：https://jx.mfjx.tk/tvbox.json

3. 随机轮换壁纸：

（1）https://tian.chuqiuyu.tk  自制横屏精美壁纸1

（2）https://yun.chuqiuyu.tk  自制横屏精美壁纸2

（3）https://shuping.chuqiuyu.tk  自制竖屏精美壁纸

（4）https://jianbian.chuqiuyu.tk  自制渐变简约壁纸

（5）https://bing.img.run/rand.php

（6）http://www.kf666888.cn/api/tvbox/img

（7）https://picsum.photos/1280/720/?blur=10

（8）http://刚刚.live/图 

（9）http://饭太硬.ga/深色壁纸/api.php

（10）https://www.dmoe.cc/random.php

（11）https://api.btstu.cn/sjbz/zsy.php

（12）https://api.btstu.cn/sjbz/?lx=dongman

（13）http://api.btstu.cn/sjbz/?lx=meizi

（14）http://api.btstu.cn/sjbz/?lx=suiji

（15）https://pictures.catvod.eu.org/

如果喜欢，请复刻自用，切勿传播。谢谢！

尽自己所能更新，不保证配置的有效性和时效性。

